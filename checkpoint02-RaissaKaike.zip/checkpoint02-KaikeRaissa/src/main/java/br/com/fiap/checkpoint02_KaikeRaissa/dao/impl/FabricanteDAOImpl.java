package br.com.fiap.checkpoint02_KaikeRaissa.dao.impl;

import br.com.fiap.checkpoint02_KaikeRaissa.dao.HibernateGenericDAO;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Fabricante;

public class FabricanteDAOImpl extends HibernateGenericDAO<Fabricante, Long> {

	private static FabricanteDAOImpl instance = null;

	public static FabricanteDAOImpl getInstance() {
		if (instance == null) {
			instance = new FabricanteDAOImpl();
		}

		return instance;
	}

	private FabricanteDAOImpl() {
		super(Fabricante.class);
	}
}
