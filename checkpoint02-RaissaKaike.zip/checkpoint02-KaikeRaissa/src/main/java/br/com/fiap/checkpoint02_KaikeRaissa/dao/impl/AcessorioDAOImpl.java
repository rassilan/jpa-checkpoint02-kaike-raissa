package br.com.fiap.checkpoint02_KaikeRaissa.dao.impl;

import br.com.fiap.checkpoint02_KaikeRaissa.dao.HibernateGenericDAO;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Acessorio;

public class AcessorioDAOImpl extends HibernateGenericDAO<Acessorio, Long> {

	private static AcessorioDAOImpl instance = null;

	public static AcessorioDAOImpl getInstance() {
		if (instance == null) {
			instance = new AcessorioDAOImpl();
		}

		return instance;
	}

	private AcessorioDAOImpl() {
		super(Acessorio.class);
	}
}
