package br.com.fiap.checkpoint02_KaikeRaissa.dao.impl;

import br.com.fiap.checkpoint02_KaikeRaissa.dao.HibernateGenericDAO;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Carro;

public class CarroDAOImpl extends HibernateGenericDAO<Carro, Long> {

	private static CarroDAOImpl instance = null;

	public static CarroDAOImpl getInstance() {
		if (instance == null) {
			instance = new CarroDAOImpl();
		}

		return instance;
	}

	private CarroDAOImpl() {
		super(Carro.class);
	}
}
