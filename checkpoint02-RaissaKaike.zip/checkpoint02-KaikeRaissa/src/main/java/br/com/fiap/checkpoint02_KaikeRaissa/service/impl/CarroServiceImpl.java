package br.com.fiap.checkpoint02_KaikeRaissa.service.impl;

import java.util.List;

import br.com.fiap.checkpoint02_KaikeRaissa.dao.impl.CarroDAOImpl;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Acessorio;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Carro;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Fabricante;
import br.com.fiap.checkpoint02_KaikeRaissa.service.GenericService;

public class CarroServiceImpl extends GenericService<Carro, Long> {
	private static CarroServiceImpl instance = null;
	private CarroDAOImpl carroDAO;
	
	private CarroServiceImpl() {
		this.carroDAO = CarroDAOImpl.getInstance();
	}
	
	public static CarroServiceImpl getInstance() {
		
		if (instance == null) {
			instance = new CarroServiceImpl();
		}
		
		return instance;
		
	}
	
	@Override
	public void cadastrar(Carro instance) {
		try {
			carroDAO.salvar(instance, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}
	
	public void cadastrarComFabricanteEAcessorios(Carro carro, Fabricante fabricante, List<Acessorio> acessorios) {
		try {
			
			carro.setAcessorios(acessorios);
			carro.setFabricante(fabricante);
			carroDAO.salvar(carro, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}
	
	@Override
	public void atualizar(Carro instance) {
		try {
			carroDAO.atualizar(instance, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public void remover(Long id) {
		try {
			carroDAO.remover(id, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public Carro obter(Long id) {
		Carro carro = null;
		
		try {
			carro = carroDAO.obterPorId(id, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction();
		} finally {
			closeEntityManager();
		}
	
		return carro;
	}

	
	@Override
	public List<Carro> listar() {
		List<Carro> carros = null;
		
		try {
			carros = carroDAO.listar(getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction();
		} finally {
			closeEntityManager();
		}
	
		return carros;
	}

}
