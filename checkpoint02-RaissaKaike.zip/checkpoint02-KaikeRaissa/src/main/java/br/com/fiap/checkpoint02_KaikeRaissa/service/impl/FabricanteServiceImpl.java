package br.com.fiap.checkpoint02_KaikeRaissa.service.impl;

import java.util.List;

import br.com.fiap.checkpoint02_KaikeRaissa.dao.impl.FabricanteDAOImpl;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Fabricante;
import br.com.fiap.checkpoint02_KaikeRaissa.service.GenericService;

public class FabricanteServiceImpl extends GenericService<Fabricante, Long> {
	private static FabricanteServiceImpl instance = null;
	private FabricanteDAOImpl fabricanteDAO;
	
	private FabricanteServiceImpl() {
		this.fabricanteDAO = FabricanteDAOImpl.getInstance();
	}
	
	public static FabricanteServiceImpl getInstance() {
		
		if (instance == null) {
			instance = new FabricanteServiceImpl();
		}
		
		return instance;
		
	}
	
	@Override
	public void cadastrar(Fabricante instance) {
		try {
			fabricanteDAO.salvar(instance, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}
	
	@Override
	public void atualizar(Fabricante instance) {
		try {
			fabricanteDAO.atualizar(instance, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public void remover(Long id) {
		try {
			fabricanteDAO.remover(id, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction().rollback();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public Fabricante obter(Long id) {
		Fabricante fabricante = null;
		
		try {
			fabricante = fabricanteDAO.obterPorId(id, getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction();
		} finally {
			closeEntityManager();
		}
	
		return fabricante;
	}

	
	@Override
	public List<Fabricante> listar() {
		List<Fabricante> fabricantes = null;
		
		try {
			fabricantes = fabricanteDAO.listar(getEntityManager());
			
		} catch (Exception e) {
			e.printStackTrace();
			getEntityManager().getTransaction();
		} finally {
			closeEntityManager();
		}
	
		return fabricantes;
	}

}
