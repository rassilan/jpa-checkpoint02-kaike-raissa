package br.com.fiap.checkpoint02_KaikeRaissa.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tb_fabricante")
@SequenceGenerator(name = "fabricante", sequenceName = "SQ_TB_FABRICANTE", allocationSize = 1)
public class Fabricante implements Serializable {

	private static final long serialVersionUID = 5015832939113931798L;

	public Fabricante() {
	}
	
	public Fabricante(String descricao) {
		super();
		this.descricao = descricao;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "fabricante")
	private Long id;

	@Column(name = "ds_descricao", length = 80)
	private String descricao;
	
	@OneToMany(mappedBy = "fabricante", fetch = FetchType.EAGER)
	private List<Carro> carro;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public List<Carro> getCarro() {
		return carro;
	}

	public void setCarro(List<Carro> carro) {
		this.carro = carro;
	}

	@Override
	public String toString() {
		return "\n Fabricante [Descrição: " + descricao + "]\n";
	}

}
