package br.com.fiap.checkpoint02_KaikeRaissa;

import java.util.List;

import br.com.fiap.checkpoint02_KaikeRaissa.entity.Acessorio;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Carro;
import br.com.fiap.checkpoint02_KaikeRaissa.entity.Fabricante;
import br.com.fiap.checkpoint02_KaikeRaissa.service.impl.AcessorioServiceImpl;
import br.com.fiap.checkpoint02_KaikeRaissa.service.impl.CarroServiceImpl;
import br.com.fiap.checkpoint02_KaikeRaissa.service.impl.FabricanteServiceImpl;


public class App {

	public static void main(String[] args) {
		
		//Instanciando service para executar operações na entidade Carro
		CarroServiceImpl carroService = CarroServiceImpl.getInstance();
		FabricanteServiceImpl fabricanteService = FabricanteServiceImpl.getInstance();
		AcessorioServiceImpl acessorioService = AcessorioServiceImpl.getInstance();
		
		//Criando instâncias de Carro, Acessorios e Fabricante
		Carro carro1 = new Carro("abc-1234", "vermelho", "5D7 6BeHrT 8A AA3037");
		Acessorio acessorio1 = new Acessorio("Volante");
		Acessorio acessorio2 = new Acessorio("Pneu");
		Fabricante fabricante1 = new Fabricante("Chevrolet");
		
		//Cadastrando Fabricante e Acessorios
		fabricanteService.cadastrar(fabricante1);
		acessorioService.cadastrar(acessorio1);
		acessorioService.cadastrar(acessorio2);
		
		//Cadastrando fabricante e acessorios do carro
		List<Fabricante> fabricantes = fabricanteService.listar();
		List<Acessorio> acessorios = acessorioService.listar();
		Fabricante fabricante = fabricantes.get(0);
		
		carro1.setFabricante(fabricante);
		carro1.setAcessorios(acessorios);
		
		carroService.cadastrar(carro1);
		
		carroService.listar().forEach(System.out::println);
		fabricanteService.listar().forEach(System.out::println);
		acessorioService.listar().forEach(System.out::println);
	}
}
